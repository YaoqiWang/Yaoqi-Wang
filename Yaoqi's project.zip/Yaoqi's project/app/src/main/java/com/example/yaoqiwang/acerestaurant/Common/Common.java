package com.example.yaoqiwang.acerestaurant.Common;

import com.example.yaoqiwang.acerestaurant.model.User;

/**
 * Created by yaoqiwang on 12/4/17.
 */

public class Common {
    public static User currentUser;

}
