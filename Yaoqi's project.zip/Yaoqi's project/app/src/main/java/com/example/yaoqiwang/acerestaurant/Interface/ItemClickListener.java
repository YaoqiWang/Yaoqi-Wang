package com.example.yaoqiwang.acerestaurant.Interface;

import android.view.View;

/**
 * Created by yaoqiwang on 12/8/17.
 */

public interface ItemClickListener {
    void Onclike (View view, int position, boolean isLongClick);
}
