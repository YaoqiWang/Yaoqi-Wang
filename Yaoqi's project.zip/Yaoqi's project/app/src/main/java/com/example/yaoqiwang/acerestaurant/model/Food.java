package com.example.yaoqiwang.acerestaurant.model;

/**
 * Created by yaoqiwang on 12/12/17.
 */

public class Food {
    private String Name,Image,Price,Description,MenuID;

    public Food() {
    }

    public Food(String name, String image, String price, String description, String menuID) {
        Name = name;
        Image = image;
        Price = price;
        Description = description;
        MenuID = menuID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getMenuID() {
        return MenuID;
    }

    public void setMenuID(String menuID) {
        MenuID = menuID;
    }
}

